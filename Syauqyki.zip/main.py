import matematika

jari_jari = float(input("masukan jari-jari :"))
luas_lingkaran = matematika.luas_lingkaran(jari_jari)
print(f"Luas lingkaran dengan jari-jari {jari_jari} adalah {luas_lingkaran:.2F}.")

sisi = float(input("masukan sisi"))
luas_persegi = matematika.luas_persegi(sisi)
print(f"Luas persegi dengan sisi {sisi} adalah {luas_persegi: }.")

