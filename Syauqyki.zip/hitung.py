import math

angka = float(input("Masukan angka kuadrat = "))
akarkuadrat = math.sqrt(angka)
print(f"Hasil kuadrat dari {angka} adalah {akarkuadrat:.2F}.")

angka_fak = int(input("Masukkan angka faktorial = "))
faktorial = math.factorial(angka_fak)
print(f"Hasil faktorial dari {angka_fak} adalah {faktorial:.2F}")

basis = int(input("Masukan basis = "))
eksponen = int(input("Masukan eksponen = "))
pangkat = math.pow(basis, eksponen)
print(f"{basis} pangkat {eksponen} adalah {pangkat}")

angka_bulat_atas = float(input("Masukan angka bulat atas = "))
bulat_atas = math.ceil(angka_bulat_atas)
print(f"Pembulatan atas dari {angka_bulat_atas} adalah {bulat_atas}")

angka_bulat_bawah = float(input("Masukan angka bulat bawah= "))
bulat_bawah = math.floor(angka_bulat_bawah)
print(f"Pembulatan bawah dari {angka_bulat_bawah} adalah {bulat_bawah}")

